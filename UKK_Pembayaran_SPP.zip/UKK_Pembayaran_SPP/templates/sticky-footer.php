<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>

<footer class="container sticky-footer">
	<div class="my-auto">
		<div class="copyright text-center mt-3">
			<span>Copyright &copy; UKK RPL <?= date('Y');  ?></span>
		</div>
	</div>
</footer>

